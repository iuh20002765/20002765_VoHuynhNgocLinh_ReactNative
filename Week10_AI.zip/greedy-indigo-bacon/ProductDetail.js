import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

const ProductDetail = ({ route }) => {
  const { bike } = route.params;
  
  return (
    <View style={styles.container}>
      <Image source={bike.image} style={styles.productImage} />

      <View style={styles.content}>
        <Text style={styles.bikeName}>{bike.name}</Text>
        <View style={styles.priceContainer}>
          <Text style={styles.discountText}>{bike.discount}% OFF</Text>
          <Text style={styles.originalPrice}>
            ${bike.originalPrice.toFixed(0)}
          </Text>
          <Text style={styles.discountedPrice}>${bike.price}</Text>
        </View>

        <Text style={styles.sectionTitle}>Description</Text>
        <Text style={styles.descriptionText}>{bike.description}</Text>

        <View style={styles.footer}>
          <TouchableOpacity style={styles.heartButton}>
            <Text style={styles.heartIcon}>{bike.liked ? '♥' : '♡'}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.addToCartButton}>
            <Text style={styles.addToCartText}>Add to Cart</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9f9f9',
    alignItems: 'center',
  },
  productImage: {
    width: '100%',
    height: 250,
    resizeMode: 'contain',
    backgroundColor: '#fce8e8',
  },
  content: {
    flex: 1,
    padding: 20,
    width: '100%',
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    marginTop: -20,
  },
  bikeName: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  priceContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: 10,
  },
  discountText: {
    color: '#ff5e5e',
    fontSize: 16,
    marginRight: 10,
    fontWeight: '600',
  },
  originalPrice: {
    fontSize: 16,
    color: '#999',
    textDecorationLine: 'line-through',
    marginRight: 10,
  },
  discountedPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
  },
  descriptionText: {
    fontSize: 16,
    lineHeight: 24,
    color: '#666',
  },
  footer: {
    flexDirection: 'row',
    marginTop: 30,
    justifyContent: 'space-between',
  },
  heartButton: {
    backgroundColor: '#fff',
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 50,
    width: 50,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heartIcon: {
    fontSize: 24,
    color: '#ff5e5e',
  },
  addToCartButton: {
    flex: 1,
    marginLeft: 10,
    backgroundColor: '#ff5e5e',
    paddingVertical: 15,
    borderRadius: 50,
    alignItems: 'center',
  },
  addToCartText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
});

export default ProductDetail;
