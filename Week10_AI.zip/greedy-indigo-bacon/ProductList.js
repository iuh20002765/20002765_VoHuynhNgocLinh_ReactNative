import React, { useState } from 'react';
import { FlatList, View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Ionicons from 'react-native-vector-icons/Ionicons';

const bikes = [
  {
    id: 1,
    name: 'Pinarello',
    price: 1800,
    originalPrice: 2100, 
    discount: 15, 
    image: require('./image/bike_blue.png'),
    type: 'RoadBike',
    liked: false,
    description: 'The Pinarello is designed for ultimate road biking performance with lightweight materials and aerodynamic features.',
  },
  {
    id: 2,
    name: 'Pina Mountain',
    price: 1700,
    originalPrice: 2000,
    discount: 15,
    image: require('./image/bike_red.png'),
    type: 'Mountain',
    liked: false,
    description: 'Pina Mountain bikes are built for tackling rugged terrain with superior suspension and durability.',
  },
  {
    id: 3,
    name: 'Pina Bike',
    price: 1500,
    originalPrice: 1800,
    discount: 17,
    image: require('./image/bike_pink.png'),
    type: 'RoadBike',
    liked: false,
    description: 'A lightweight and affordable road bike ideal for beginners and long-distance riders.',
  },
  {
    id: 4,
    name: 'Pinarello',
    price: 1900,
    originalPrice: 2250,
    discount: 16,
    image: require('./image/bike_red2.png'),
    type: 'Mountain',
    liked: false,
    description: 'Experience the thrill of mountain biking with the premium build of the Pinarello series.',
  },
  {
    id: 5,
    name: 'Pina Mountain',
    price: 2700,
    originalPrice: 3200,
    discount: 15,
    image: require('./image/bike_pink.png'),
    type: 'Mountain',
    liked: false,
    description: 'Pina Mountain offers unparalleled comfort and control for mountain biking enthusiasts.',
  },
  {
    id: 6,
    name: 'Pinarello',
    price: 1350,
    originalPrice: 1600,
    discount: 16,
    image: require('./image/bike_red2.png'),
    type: 'RoadBike',
    liked: false,
    description: 'Perfect for commuters, the Pinarello RoadBike offers efficiency and reliability in every ride.',
  },
  {
    id: 7,
    name: 'Pina Mountain',
    price: 1700,
    originalPrice: 2000,
    discount: 15,
    image: require('./image/bike_blue.png'),
    type: 'Mountain',
    liked: false,
    description: 'Take your mountain adventures to the next level with Pina Mountain’s superior handling.',
  },
  {
    id: 8,
    name: 'Pina Mountain',
    price: 1700,
    originalPrice: 2000,
    discount: 15,
    image: require('./image/bike_red.png'),
    type: 'Mountain',
    liked: false,
    description: 'Engineered for challenging terrains, Pina Mountain provides unmatched stability and durability.',
  },
  {
    id: 9,
    name: 'Pina Mountain',
    price: 1700,
    originalPrice: 2000,
    discount: 15,
    image: require('./image/bike_red.png'),
    type: 'RoadBike',
    liked: false,
    description: 'An all-rounder road bike for smooth rides with robust construction and great value.',
  },
  {
    id: 10,
    name: 'Pina Mountain',
    price: 1700,
    originalPrice: 2000,
    discount: 15,
    image: require('./image/bike_red.png'),
    type: 'Mountain',
    liked: false,
    description: 'Conquer any trail with the Pina Mountain bike, designed for adventure and reliability.',
  },
];

const BikeList = () => {
  const [selectedFilter, setSelectedFilter] = useState('All');
  const navigation = useNavigation();

  const handleFilter = (filter) => {
    setSelectedFilter(filter);
  };

  const handleLikeToggle = (id) => {
    bikes.forEach((bike) => {
      if (bike.id === id) bike.liked = !bike.liked;
    });
  };

  const filteredData = selectedFilter === 'All' ? bikes : bikes.filter(bike => bike.type === selectedFilter);

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.bikeItem}
      onPress={() => navigation.navigate('ProductDetail', { bike: item })}
    >
      <View>
        <TouchableOpacity
          style={styles.heartIcon}
          onPress={() => handleLikeToggle(item.id)}
        >
          <Ionicons
            name={item.liked ? 'heart' : 'heart-outline'}
            size={24}
            color={item.liked ? 'red' : 'gray'}
          />
        </TouchableOpacity>
        <Image source={item.image} style={styles.bikeImage} />
        <Text style={styles.bikeName}>{item.name}</Text>
        <Text style={styles.bikePrice}>${item.price}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.filterContainer}>
        <TouchableOpacity onPress={() => handleFilter('All')}>
          <Text style={[styles.filterButton, selectedFilter === 'All' && styles.selectedFilter]}>All</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => handleFilter('RoadBike')}>
          <Text style={[styles.filterButton, selectedFilter === 'RoadBike' && styles.selectedFilter]}>RoadBike</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => handleFilter('Mountain')}>
          <Text style={[styles.filterButton, selectedFilter === 'Mountain' && styles.selectedFilter]}>Mountain</Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={filteredData}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
        numColumns={2}
        columnWrapperStyle={styles.row}
        contentContainerStyle={styles.listContent}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
    padding: 10,
  },
  filterContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 15,
  },
  filterButton: {
    fontSize: 16,
    padding: 10,
    color: '#333',
  },
  selectedFilter: {
    color: '#fff',
    backgroundColor: '#007bff',
    borderRadius: 5,
    paddingHorizontal: 12,
    paddingVertical: 5,
  },
  row: {
    justifyContent: 'space-between',
  },
  bikeItem: {
    flex: 1,
    margin: 10,
    padding: 10,
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  bikeImage: {
    width: '100%',
    height: 150,
    resizeMode: 'contain',
  },
  bikeName: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 10,
    textAlign: 'center',
  },
  bikePrice: {
    fontSize: 14,
    color: 'gray',
    marginTop: 5,
    textAlign: 'center',
  },
  listContent: {
    paddingBottom: 20,
  },
  heartIcon: {
    position: 'absolute',
    top: 10,
    left: 10,
    zIndex: 10,
  },
});

export default BikeList;
