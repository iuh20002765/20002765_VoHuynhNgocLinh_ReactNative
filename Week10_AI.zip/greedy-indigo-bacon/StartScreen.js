import React from 'react';
import { View, Image, Text, TouchableOpacity, StyleSheet } from 'react-native';

const StartScreen = ({navigation}) => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>A premium online store for sporters and their stylish choice</Text>
      </View>

      <View style={styles.bikeImageContainer}>
        <Image source={require('./image/bike_blue.png')} style={styles.bikeImage} />
      </View>

      <View style={styles.shopSection}>
        <Text style={styles.shopTitle}>POWER BIKE SHOP</Text>
        <TouchableOpacity style={styles.getStartedButton} onPress={() => navigation.navigate('ProductList')}>
          <Text style={styles.buttonText}>Get Started</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F2F2F2',
  },
  header: {
    marginTop: 40,
    marginBottom: 30,
  },
  headerText: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  bikeImageContainer: {
    width: '80%',
    height: 300,
    marginBottom: 30,
  },
  bikeImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  shopSection: {
    alignItems: 'center',
  },
  shopTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  getStartedButton: {
    backgroundColor: '#F05A28',
    padding: 15,
    borderRadius: 10,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
});

export default StartScreen;